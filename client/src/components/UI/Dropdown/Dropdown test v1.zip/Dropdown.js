import React from 'react'

import './Dropdown.scss'

const Dropdown = () => {

  let arr = [ {_id: 0, name: "mobile", r: ["samsung", "xiomi"]}, {_id: 1, name: "cpu", r:["i5", "i7"]}]

  // const [curIndex, setCurIndex] = React.useState(1)
  const [curIndex, setCurIndex] = React.useState([])

  function collapse(_id){ 
    let aleadyOpen = curIndex.indexOf(_id)
    if(aleadyOpen === -1){
      setCurIndex([...curIndex, _id])
    }else{
      let g = curIndex.filter(t=>t !== _id )
      setCurIndex([...g])
    }
  }

  return (
    <div>
      <h1>Dropdown component</h1>
      <ul className="menu">
        {arr.map(t=>{
          return (
            <div className="one">
              <li className="one_step_menu" onClick={(e)=>collapse(t._id)}>{t.name}</li>
             {  curIndex.indexOf(t._id) !== -1 && (
                <div className="drop_down_menu">
                  { t.r.map(g=><li>{g}</li>) }
                </div>
             ) }
            </div>
          )
        })}
      </ul>

    </div>
  )
}


export default Dropdown
